The applications is started by running nodemon or npm start.
dbName: citiesDb
all api is according to the convention
The back end works for all the required features 
Validation have been added both to the front end and backend side
api hardning has been also implemented
